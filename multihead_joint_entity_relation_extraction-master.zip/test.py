import pandas as pd
import gensim

word_vectors = gensim.models.KeyedVectors.load_word2vec_format(
    'data/2019LIC_Test3/wordEmbeddings.txt', binary=False)
print(word_vectors)