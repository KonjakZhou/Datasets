import zipfile
import json
import os
import numpy as np
import tensorflow as tf
import collections
import math
import hashlib
import utils

class dataset(object):
    def __init__(self, dataDir=None):
        if not dataDir:
            dataDir = os.path.join(os.getcwd(),
                                    "data/2019LIC_Test3/2019LIC_Test3.zip")
        self._dataDir = dataDir
        self._dataPath = '/'.join(self._dataDir.split('/')[:-1])
        self._hashDir = os.path.join(self._dataPath, "hash")
        self._files = zipfile.ZipFile(self._dataDir).namelist()
        self.unzipFile()
        self._data = dict()

    def unzipFile(self):
        """
        unzip files in 2019LIC_Test3.zip to json files
        :return: none
        """
        self.unzip(self._dataDir)
        for fileName in self._files:
            if self.isZip(fileName):
                self.unzip(os.path.join(self._dataPath, fileName))
        return

    def loadData(self, name):
        """
        :param name: test, test1, train or dev
        :return: "${dataName}.json", ${data}
        """
        if name not in ["test", "test1", "train", "dev"]:
            raise RuntimeError("data not in \"train\", \"dev\" or \"test\"")

        if name.startswith("test"):
            if name[-1] == '1':
                dataOnProcess = 'test_data1_postag.json.zip'
            else:
                dataOnProcess = 'test_data_postag.json.zip'
        else:
            dataOnProcess = name + "_data.json.zip"

        # 载入文件数据
        dataName = '.'.join(dataOnProcess.split('.')[:-1])
        if name=="test1":
            dataName = name + "_data_postag.json"

        #判断是否已读入数据
        if dataName in self._data:
            return dataName, self._data[dataName]

        print("{} is loading...".format(dataOnProcess), end=" ")
        dataDir = os.path.join(self._dataPath, dataName)
        if not os.path.exists(dataDir):
            #解压文件
            zipDir = os.path.join(self._dataPath, dataOnProcess)
            if not os.path.exists(zipDir):
                raise RuntimeError("no such file: " + zipDir)
            self.unzip(zipDir)

        with open(dataDir, encoding='utf-8', mode='r') as fo:
            data = fo.readlines()
        print('Done.')
        self._data[dataName] = data
        return dataName, data

    def dataFlush(self, name, remake=False):
        """
        :param name: train,dev,test or test1
        :return: outputDir (absolute directory of output file)
        """
        dataName, data = self.loadData(name)
        # 检查文件完整性，完整则直接退出
        outputFileDir = os.path.join(self._dataPath,
                                     '.'.join(dataName.split('.')[:-1]))
        if not remake:
            if self.checkFileIntegrity(outputFileDir):
                return outputFileDir

        print("{} is on flushing...".format(dataName))
        if os.path.exists(outputFileDir):
            os.remove(outputFileDir)

        count = 0
        for line in data:
            print("\r{}/{} completed...".format(count, len(data)), end="")
            info = json.loads(line)
            text = info['text']
            result = [[i, text[i], "O", [], []] for i in range(len(text))]

            if not name.startswith("test"):
                spo_list = info['spo_list']
                for spo in spo_list:
                    loc_obj = text.find(spo['object'])
                    len_obj = len(spo['object'])
                    loc_sub = text.find(spo['subject'])
                    len_sub = len(spo['subject'])

                    #处理BIO
                    result[loc_obj][2] = 'B-' + spo['object_type']
                    for i in range(1, len_obj):
                        result[loc_obj + i][2] = 'I-' + spo['object_type']
                    result[loc_sub][2] = 'B-' + spo['subject_type']
                    for i in range(1, len_sub):
                        result[loc_sub + i][2] = 'I-' + spo['subject_type']

                    #处理关系
                    result[loc_sub + len_sub -1][3].append(spo['predicate'])
                    result[loc_sub + len_sub -1][4].append(loc_obj + len_obj -1)

            #填充空白
            for item in result:
                if not item[3]:
                    item[3] = ['N']
                if not item[4]:
                    item[4] = [item[0]]

            #输出到文件
            with open(outputFileDir, encoding='utf-8', mode='a+') as fo:
                tag = '#doc '+ str(count) + '\n'
                fo.write(tag)
                for item in result:
                    output = ""
                    for ele in item:
                        output += (str(ele) + '\t')
                    output = output[:-1] + '\n'
                    fo.write(output)
                count += 1
        #写入哈希值
        if  os.path.exists(self._hashDir):
            with open(self._hashDir, encoding="utf-8", mode='r') as fo:
                hashValue = json.load(fo)
        else:
            hashValue = dict()

        with open(outputFileDir, encoding="utf-8", mode='r') as fo:
            dataa = fo.readlines()

        dataa = str(dataa).encode("utf-8")
        hashValue[outputFileDir] = hashlib.sha256(dataa).hexdigest()
        with open(self._hashDir, encoding="utf-8", mode="w+") as fo:
            json.dump(hashValue,fo)

        print("\r{}/{} completed...\n".format(count, len(data)))
        return outputFileDir

    def getSentences(self, name):
        """
        :param name: train,dev,test or test1
        :return: sentences (of {$name} dataset)
        """
        _, data = self.loadData(name)
        sentences = list()
        for line in data:
            info = json.loads(line)
            sentences.append(info['text'])
        return sentences

    def checkFileIntegrity(self, fileDir):
        """
        :param fileDir: absolute directory of the file of flushed data
        :return: True: the file is integrate
                  False: the file is not integrate
        """
        # no hash file
        if not os.path.exists(self._hashDir):
            return False

        # no file to check
        if not os.path.exists(fileDir):
            return False

        #check hash
        with open(self._hashDir, encoding="utf-8", mode='r') as fo:
            hashValue = json.load(fo)

        if fileDir not in hashValue:
            return False
        hashValue = hashValue[fileDir]

        with open(fileDir, encoding="utf-8", mode='r') as fo:
            dataa = fo.readlines()
        dataa = str(dataa).encode("utf-8")
        hashFile = hashlib.sha256(dataa).hexdigest()

        if hashValue==hashFile:
            return True

        return False

    @staticmethod
    def isZip(name):
        """
        :param name: file name to check
        :return: whether file to check is a zip file or not
        """
        if name.split('.')[-1].lower() == 'zip':
            return True
        return False

    @staticmethod
    def unzip(file_name):
        """unzip zip file to current path"""
        if file_name.split('.')[-1].lower() != "zip":
            raise RuntimeError("not a zip file: " + file_name)

        zip_file = zipfile.ZipFile(file_name)

        dataPath = '/'.join(file_name.split('/')[:-1])

        for name in zip_file.namelist():
            zip_file.extract(name, dataPath)
        zip_file.close()


class NLPmodel(object):
    """
    词嵌入基类，读取句子，划分词语，读取格式为ASCII字符串，汉字为utf-8
    """
    def __init__(self,
                 dataPath=None,
                 dataList=None,
                 aimPath = None ):

        if not (dataPath or dataList):
            if not dataPath:
                raise RuntimeError("Nowhere to load data")
            if not dataList:
                raise RuntimeError("Not input data needed")

        if dataPath:
            with open(dataPath, encoding="utf-8", mode="r") as fo:
                dataList = fo.readlines()

        if not aimPath:
            aimPath = os.path.join(os.getcwd(), "NLP_Data/")

        self._aimPath = aimPath
        self._sentences = dataList
        self._word2IndexMap, self._index2WordMap = self._map()
        self.watch = utils.watch()

        self._map()
        self._N_sentence = len(self._sentences)
        self._N_vocabulary = len(self._index2WordMap)

    def _map(self):
        word2IndexMap = dict()
        count = 0
        for sent in self._sentences:
            for word in sent:
                if word not in word2IndexMap:
                    word2IndexMap[word] = count
                    count += 1

        index2WordMap = dict(zip(word2IndexMap.values(), word2IndexMap.keys()))
        return word2IndexMap, index2WordMap

class skipGram(NLPmodel):
    """
    skipGram模型，默认窗口长度为1，嵌入向量维度200，负采样数5
    默认语句中词语有序
    """
    def __init__(self,
                 dataPath=None,
                 dataList=None,
                 aimPath=None,
                 windowSize = 2,
                 embeddingDimension = 200,
                 batchSize = 1024,
                 negativeSamples = 5):

        super().__init__(dataPath=dataPath, dataList=dataList, aimPath=aimPath)
        self._embeddingDimension = embeddingDimension
        self._negativeSamples = negativeSamples
        self._windowSize = windowSize
        self._batchSize = batchSize
        self._batchStart = 0

    cnt_sent = 0
    cnt_word = 0

    def _nextBatch(self,batchSize, windowSize):
        """
        获得下一批数据
        :return: (input,label)
        """
        batch = np.ndarray(shape = batchSize, dtype=np.int32)
        labels = np.ndarray(shape = (batchSize,1), dtype=np.int32)
        buffer = collections.deque(maxlen = windowSize+1)
        sentence = self._sentences[self.cnt_sent]

        for _ in range(windowSize+1):
            if self.cnt_word >= len(sentence):
                self.cnt_sent = (self.cnt_sent+1)%self._N_sentence
                self.cnt_word = 0
                sentence = self._sentences[self.cnt_sent]
            buffer.append(self._word2IndexMap[sentence[self.cnt_word]])
            self.cnt_word += 1

        for k in range(batchSize // windowSize):
            i = 0
            for j in range(1,windowSize+1):
                batch[k*windowSize+i] = buffer[0]
                labels[k*windowSize+i] = buffer[j]
                i += 1
            if self.cnt_word >= len(sentence):
                self.cnt_sent = (self.cnt_sent+1) % self._N_sentence
                self.cnt_word = 0
                sentence = self._sentences[self.cnt_sent]
            buffer.append(self._word2IndexMap[sentence[self.cnt_word]])
            self.cnt_word += 1

        i = 0
        for j in range(batchSize//windowSize * windowSize, batchSize):
            i += 1
            batch[j] = buffer[0]
            labels[j] = buffer[i]
        if self.cnt_word >= len(sentence):
            self.cnt_sent = (self.cnt_sent + 1) % self._N_sentence
            self.cnt_word = 0
            sentence = self._sentences[self.cnt_sent]
        buffer.append(self._word2IndexMap[sentence[self.cnt_word]])
        self.cnt_word += 1

        return batch, labels

    def deepLearning(self,
                     maxTrainStep = 10000,
                     normalization = False):
        """
        深度学习模型
        :return:
        """
        aimPath = self._aimPath
        aimDir = os.path.join(aimPath, 'wordEmbeddings.txt')

        if not os.path.exists(aimPath):
            os.makedirs(aimPath)

        with tf.Graph().as_default():
            with tf.name_scope('interface'):
                _inputs = tf.placeholder(tf.int32, shape=[None], name='inputs')
                _labels = tf.placeholder(tf.int32, shape=[None, 1],
                                         name='labels')

            with tf.name_scope('embeddings'):
                embeddings = tf.Variable(
                    tf.random_uniform([self._N_vocabulary,
                                       self._embeddingDimension],
                                      -1.0, 1.0),
                    dtype=tf.float32,name='embedding')
                embed = tf.nn.embedding_lookup(embeddings, _inputs)

            with tf.name_scope('noise'):
                weights = {
                    'nce':
                        tf.Variable(
                            tf.truncated_normal(
                                [self._N_vocabulary,
                                 self._embeddingDimension],
                                stddev=1.0 / math.sqrt(self._embeddingDimension)),
                        dtype=tf.float32)
                }
                bias = {
                    'nce':
                        tf.Variable(tf.constant(
                            1.0 / math.sqrt(self._embeddingDimension),
                            dtype = tf.float32,
                            shape = [self._N_vocabulary]))
                }
                loss = tf.reduce_mean(
                    tf.nn.nce_loss(weights=weights['nce'],
                                   biases=bias['nce'],
                                   inputs=embed,
                                   labels=_labels,
                                   num_sampled=self._negativeSamples,
                                   num_classes=self._N_vocabulary))

            with tf.name_scope('train'):
                globalStep = tf.Variable(0, trainable=False)
                learningRate = tf.train.exponential_decay(learning_rate=0.1,
                                                          global_step=globalStep,
                                                          decay_steps=1000,
                                                          decay_rate=0.95,
                                                          staircase=True)
                trainStep = tf.train \
                    .GradientDescentOptimizer(learningRate).minimize(loss)

            with tf.Session() as sess:

                sess.run(tf.global_variables_initializer())

                self.watch.placeZero()
                for step in range(maxTrainStep):
                    batch = self._nextBatch(batchSize=self._batchSize,
                                           windowSize=self._windowSize)
                    if step % 1000 == 0:
                        lossValue = sess.run(loss,
                                             feed_dict={_inputs: batch[0],
                                                        _labels: batch[1]})
                        print('Step {} has processed, {} used in total, '
                              'Loss is {:.5f}...'. \
                              format(step, self.watch.showTime(), lossValue))

                    sess.run(trainStep, feed_dict={_inputs: batch[0],
                                                   _labels: batch[1]})

                #输出最终Loss
                lossValue = sess.run(loss,
                                     feed_dict={_inputs: batch[0],
                                                _labels: batch[1]})
                print('Step {} has processed, {} used in total, '
                      'Loss is {:.5f}...'. \
                      format(maxTrainStep, self.watch.showTime(), lossValue))

                if normalization:
                    # 正则化
                    norm = tf.sqrt(tf.reduce_sum(tf.square(embeddings), 1,
                                                 keepdims=True))
                    normalizedEmbeddings = embeddings / norm
                    embeddingsMatrix = sess.run(normalizedEmbeddings)
                else:
                    #未经过正则化
                    embeddingsMatrix = sess.run(embeddings)

                #写入到文件
                with open(aimDir, encoding="utf-8", mode='w') as fo:
                    N_vocabulary = self._N_vocabulary
                    for i in range(self._N_vocabulary):
                        if self._index2WordMap[i].isspace():
                            N_vocabulary -= 1
                    fo.write("{:d} {:d}\n".format(N_vocabulary, self._embeddingDimension))
                    for i in range(self._N_vocabulary):
                        if not self._index2WordMap[i].isspace():
                            emb = "%s %s\n" % (self._index2WordMap[i],
                                               ' '.join(repr(num) for num in embeddingsMatrix[i]))
                            fo.write(emb)
        return

if __name__=='__main__':
    aimPath = os.path.join(os.getcwd(), "data/2019LIC_Test3/")
    aimDir = os.path.join(aimPath, "wordEmbeddings.txt")

    if os.path.exists(aimDir):
        s = input("word embeddings already exist, retrain? ([Y]es, [N]o): ")
        while s not in ["Yes", "No","Y","N"]:
            s = input('Only "[Y]es" or "[N]o": ')
        if s in ["No", "N"]:
            exit(0)

    print("File build_2019LIC.py: Procedure embedding words")

    dataNames = ['dev', 'train', 'test', 'test1']

    data = dataset()
    for name in dataNames:
        data.dataFlush(name)

    sentences = list()
    for name in dataNames:
        sentences.extend(data.getSentences(name))

    wordEmbed = skipGram(dataList=sentences,
                         aimPath=aimPath,
                         embeddingDimension=64)
    wordEmbed.deepLearning()
    print("File build_2019LIC.py: Done")